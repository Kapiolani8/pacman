console.log("bitch, im ready");
var world= [
    [2,2,2,2,2,2,2,2,2,2],
    [2,0,2,2,1,1,1,1,1,2],
    [2,1,2,2,1,2,1,2,2,2],
    [2,1,2,2,1,2,1,1,1,2],
    [2,1,1,1,1,2,1,1,2,2],
    [2,1,2,1,1,2,1,2,2,2],
    [2,1,1,1,1,2,1,1,1,2],
    [2,2,2,2,2,2,2,2,2,2]  
];

    var score = 0;


    var pacman = {
        x:  1,
        y:  1
    };


function displayWorld(){
    var output="";

    for(var i=0; i<world.length; i++){ //iterating through each ROW of world
        output = output + "\n<div class='row'>\n";
        for(var j=0; j<world[i].length; j++){ //iterating through each COL of ROW in the world
            if(world[i][j] == 2) // if position in world equals 2, then its a brick
                output = output + "<div class='brick'></div>"; //
            else if(world[i][j] == 1) //if position in world equals 1, then its a coin
            output = output + "<div class='coin'></div>";
            if(world[i][j] == 0)//if position in world equals 0, then it is empty.
            output = output + "<div class='empty'></div>";
        }
        output = output + "\n</div>" //stopping the script at the end of the div, so it doesnt run into other divs
    }
    // console.log(output);
    document.getElementById("world").innerHTML = output;

}

function displayPacman(){
    document.getElementById("pacman").style.top = pacman.y*20+"px";
    document.getElementById("pacman").style.left = pacman.x*20+"px";
}

function displayScore(){
    document.getElementById("score").innerHTML = score;

}



document.onkeydown = function(e){
    if(e.keyCode == 37 &&world[pacman.y][pacman.x-1] !=2){
        pacman.x--;
    }
    else if(e.keyCode == 39 &&world[pacman.y][pacman.x+1] !=2){
        pacman.x ++;
    }
    else if(e.keyCode == 40 &&world[pacman.y+1][pacman.x] !=2){
        pacman.y ++;
    }
    else if(e.keyCode == 38 &&world[pacman.y-1][pacman.x] !=2){
        pacman.y --;
    }

    if(world[pacman.y][pacman.x] == 1){
        world[pacman.y][pacman.x] =0;
        score+=10;
        displayWorld();
        displayScore();
    }
    // console.log(e.keyCode);

    displayPacman();
    displayScore();
}
